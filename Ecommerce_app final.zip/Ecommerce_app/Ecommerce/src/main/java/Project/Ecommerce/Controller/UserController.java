package Project.Ecommerce.Controller;

import Project.Ecommerce.Model.User;
import Project.Ecommerce.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;

    @PostMapping("/registration")
    public User save(@RequestBody User obj) {
        // Save the user data to the database using the UserService
        User savedUser = userService.saveuser(obj);
        return savedUser;
    }

    @PostMapping("/login")
    public String loginUser(@RequestBody User user) {
        String username = user.getUserName();
        String password = user.getPassword1();
        return userService.userLogin(username, password);
    }
}




