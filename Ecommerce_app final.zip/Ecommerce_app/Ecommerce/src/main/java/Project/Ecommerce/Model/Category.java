package Project.Ecommerce.Model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@Table(name="ecommerce_category")
public class Category {
    @Id
    @GeneratedValue
    @Column(name="category_id")
    private int Id;
    @Column(name="category_name")
    private String name;
    @Column(name="description")
    private String description;


    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

//    public List<Product> getProductList() {
//        return productList;
//    }
//
//    public void setProductList(List<Product> productList) {
//        this.productList = productList;
//    }
//    @Column(name="Products")
//    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
//    private List<Product> productList;
}
