package Project.Ecommerce.Controller;


import Project.Ecommerce.ExceptionHandler.IdException;
import Project.Ecommerce.Model.Category;
import Project.Ecommerce.Model.Product;
import Project.Ecommerce.Service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/category")
public class CategoryController {


    @Autowired
    CategoryService categoryService;

    @PostMapping("/add-category")
    @ResponseStatus(HttpStatus.OK)
    public Category save(@RequestBody Category obj) {
        Category productfinal = categoryService.savecategory(obj);
        return productfinal;
    }

    @DeleteMapping("/deletebyid/{id}")
    public void deletebyid(@PathVariable("id") int id) throws IdException {
        categoryService.deletebyid(id);
    }

    @GetMapping("/findall")
    public List<Category> findall() {
        return categoryService.findall();
    }

    @PostMapping("/updatebyid/{id}")
    public Category update(@PathVariable int id, @RequestBody Category obj) throws IdException {
        return categoryService.updatebyid(id, obj);
    }

    @GetMapping("/findbyname/{name}")
    public Category findbyname(@PathVariable String name) {
        return categoryService.getCategorybyname(name);
    }
    @GetMapping("/findbydes/{des}")
    public Category findbydes(@PathVariable String des) {
        return categoryService.getCategorybydes(des);
    }

}