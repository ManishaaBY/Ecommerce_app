package Project.Ecommerce.Service;

import org.springframework.stereotype.Service;
import Project.Ecommerce.Model.User;
import Project.Ecommerce.Repository.UserRepository;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private UserRepository userRepo;
    private TokenService tokenService;

    public UserService(UserRepository userRepo,TokenService tokenService) {
        this.userRepo = userRepo;
        this.tokenService = tokenService;
    }
    public User saveuser(User obj) {
        User userfinal = userRepo.save(obj);
        return userfinal;
    }
    public String userLogin(String username, String password) {
        boolean foundUser = existsByUserName(username);
        if (foundUser) {
            User user = userRepo.getUserByUsername(username);
            if (user.getPassword1().equals(password)) {
                return "{" +
                        "\"message\":" + "Successfully logged in\",\n" +
                        "\"data\": " + user + ",\n" + "\"Email:" + user.getEmail() +
                        "\n" + "token:" +
                        tokenService.createTokenFunction(user.getId())+ "\""+
                        "}";
            }
        }
        return "{" +
                "\"message\":" + "Authentication failed\",\n" + ",\n" +
                "}";
    }


    public Boolean existsByUserName(String username) {
        Optional<User> usersObj = Optional.ofNullable(userRepo.getUserByUsername(username));
        if (!usersObj.isEmpty()) {
            return true;
        }
        return false;
    }





}

