package Project.Ecommerce.Model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "ecommerce_product")
public class Product {
    //    { "name": "value", "price": "value", "description": "value" }
    @Column(name = "product_id")
    @Id
    @GeneratedValue
    private int product_id;
    @Column(name = "product_name")
    private String product_name;
    @Column(name = "price")

    private int price;


    @Column(name = "description")

    private String description;
    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

}
