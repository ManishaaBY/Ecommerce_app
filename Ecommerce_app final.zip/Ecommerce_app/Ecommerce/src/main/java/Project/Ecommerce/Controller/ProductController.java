package Project.Ecommerce.Controller;

import Project.Ecommerce.ExceptionHandler.IdException;
import Project.Ecommerce.ExceptionHandler.ProductException;
import Project.Ecommerce.Model.Category;
import Project.Ecommerce.Model.Product;
import Project.Ecommerce.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/product")
public class ProductController {
    @Autowired
    ProductService productService;

    @PostMapping("/addproduct")
    public Product saveproduct(@RequestBody Product obj) {
        return productService.saveproduct(obj);
    }

    @PostMapping("/linkproduct/{id}")
    public Product linkProduct(@PathVariable int id, @RequestBody Product product) throws ProductException {
        Product addedProduct = productService.addproduct(id, product);
        return addedProduct;
    }

    @DeleteMapping("/deletebyid/{id}")
    public void deletebyid(@PathVariable("id") int id) throws IdException {
        productService.deletebyid(id);
    }

    @GetMapping("/findall")
    public List<Product> findall() {
        return productService.findall();

    }

    @PostMapping("/updatebyid/{id}")
    public Product update(@PathVariable int id, @RequestBody Product obj) throws IdException {
        return productService.updatebyid(id, obj);
    }

    @GetMapping("/findbyname/{name}")
    public Product findbyname(@PathVariable String name) {
        return productService.getProductbyname(name);
    }
    @GetMapping("/findbydes/{des}")
    public Product findbydes(@PathVariable String des) {
        return productService.getProductBydes(des);
    }
    @GetMapping("/findbyprice/{price}")
    public Product findbyprice(@PathVariable int price) {
        return productService.getProductbyprice(price);
    }

}
