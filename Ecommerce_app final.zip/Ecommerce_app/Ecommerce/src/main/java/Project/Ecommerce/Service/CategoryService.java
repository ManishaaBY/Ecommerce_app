package Project.Ecommerce.Service;

import Project.Ecommerce.ExceptionHandler.IdException;
import Project.Ecommerce.Model.Category;
import Project.Ecommerce.Model.Product;
import Project.Ecommerce.Repository.CategoryRepository;
import Project.Ecommerce.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoryService {
    @Autowired
    CategoryRepository categoryRepo;


    public Category savecategory(Category obj) {
        Category productfinal = categoryRepo.save(obj);
        return productfinal;
    }

    public Category updatebyid(Category category) throws IdException {
        boolean res = categoryRepo.existsById(category.getId());
        if (!res) {
            throw new IdException();
        }

        Category finaluser = categoryRepo.saveAndFlush(category);
        return finaluser;


    }

    public void deletebyid(int id) throws IdException {
        if(!categoryRepo.existsById(id)){
            throw new IdException();
        }
        categoryRepo.deleteById(id);
    }

    public List<Category> findall() {
        return categoryRepo.findAll();
    }



    public Optional<Category> findbyid(int id) {
        Optional<Category> finall = categoryRepo.findById(id);
        return finall;

    }

    public Category updatebyid(int id, Category updating) throws IdException {
        Category existing = categoryRepo.findById(id).get();
        if(existing==null){
            throw new IdException();
        }
        if (updating.getName() != null) {
            existing.setName(updating.getName());
        }
        if (updating.getDescription() != null) {
            existing.setDescription(updating.getDescription());
        }
        return savecategory(existing);

    }
    public Category getCategorybyname(String name){
        return categoryRepo.getCategoryByName(name);
    }
    public Category getCategorybydes(String des){
        return categoryRepo.getCategoryByDescription(des);
    }
}



