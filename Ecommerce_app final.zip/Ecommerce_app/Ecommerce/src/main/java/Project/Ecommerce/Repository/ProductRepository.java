package Project.Ecommerce.Repository;

import Project.Ecommerce.Model.Product;
import Project.Ecommerce.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends JpaRepository<Product,Integer> {

    @Query(value = "SELECT p FROM Product p WHERE p.product_name = :productName")

    Product getProductByProductName(String productName);
    @Query(value="SELECT p FROM Product p WHERE p.price=:Price")
    Product getProductByPrice(int Price);
    @Query(value="SELECT p FROM Product p WHERE p.description=:Description")
    Product getProductBydescription(String Description);
}