package Project.Ecommerce.Service;

import Project.Ecommerce.ExceptionHandler.IdException;
import Project.Ecommerce.ExceptionHandler.ProductException;
import Project.Ecommerce.Model.Category;
import Project.Ecommerce.Model.Product;
import Project.Ecommerce.Repository.CategoryRepository;
import Project.Ecommerce.Repository.ProductRepository;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import Project.Ecommerce.Service.ProductService;

import java.util.List;
import java.util.Optional;


@Service
public class ProductService {
    private final ProductRepository productRepo;
    private final CategoryRepository categoryRepo;

    @Autowired
    public ProductService(ProductRepository productRepo, CategoryRepository categoryRepo) {
        this.productRepo = productRepo;
        this.categoryRepo = categoryRepo;
    }

    public Product saveproduct(Product obj) {
        Product productfinal = productRepo.save(obj);
        return productfinal;
    }

    public Product addproduct(int category_id, Product product1) throws ProductException {

        Category category = categoryRepo.findById(category_id).get();
        if (category == null) {
            throw new ProductException("Category not found");
        }

        product1.setCategory(category);
        Product savedProduct = productRepo.save(product1);
        Product product = new Product();
        product.setProduct_id(savedProduct.getProduct_id());
        product.setProduct_name(savedProduct.getProduct_name());
        product.setPrice(savedProduct.getPrice());
        product.setCategory(savedProduct.getCategory());
        product.setDescription(savedProduct.getDescription());
        return product;
    }

    public void deletebyid(int id) throws IdException {
        if (!existsbyid(id)) {
            throw new IdException("id is not found");
        } else {

            productRepo.deleteById(id);
        }
    }

    public List<Product> findall() {
        List<Product> finall = productRepo.findAll();
        return finall;

    }


    public boolean existsbyid(int id) {
        return productRepo.existsById(id);
    }

    public Product updatebyid(int id, Product updating) throws IdException {
        if (!productRepo.existsById(id)) {
            throw new IdException();
        }
        Product existing = productRepo.findById(id).get();
        if (updating.getProduct_name() != null) {
            existing.setProduct_name(updating.getProduct_name());
        }
        if (updating.getDescription() != null) {
            existing.setDescription(updating.getDescription());
        }

        return saveproduct(existing);


    }

    public Product getProductbyname(String name) {
        return productRepo.getProductByProductName(name);
    }
    public Product getProductbyprice(int Price) {
        return productRepo.getProductByPrice(Price);
    }
    public Product getProductBydes(String des) {
        return productRepo.getProductBydescription(des);
    }

    public Optional<Product> findbyid(int id) {
        if (!productRepo.existsById(id)) {
            return null;
        }
        Optional<Product> finall = productRepo.findById(id);
        return finall;

    }
}






